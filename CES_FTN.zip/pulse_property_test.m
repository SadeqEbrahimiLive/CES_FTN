%% pulse_property_test.m
% Deterministic validation of a selected CES pole set against SRRC.
%

clear; clc; close all;

%% ===================== 1) Parameters ===================================
pulseTypes = {'rrc','ces'};
nPulse = numel(pulseTypes);

spanSide = 8;                  % implemented numerical support: [-8,+8] Ts
spanRRC  = 2*spanSide;
beta     = 0.05;

% Selected CES poles for tau = 0.7:
theta=[ -0.687894 -1.093351 -0.988055 1.690138 -0.116332 -2.664607 ];
Rs  = 1e6;
SPS = 10;
fs  = SPS*Rs;

M  = 8;
k  = log2(M);
Rc = 1/2;

tau_target = 0.7;
L_FTN      = round(tau_target*SPS);
tau_eff    = L_FTN/SPS;

mask = 0.99;
NfftPulse       = 8192;
KaliasCardinal  = 20;

% High-resolution deterministic metric grid:
nfftMetric = 16384;

Klist = [5 16 32 64 128];

fprintf('=== SELECTED-POLE VALIDATION (CORRECTED) ===\n');
fprintf('M=%d, Rs=%.3e sym/s, gross coded Rb=%.3e bit/s, Rc=%.3f\n', ...
    M, Rs, Rs*k, Rc);
fprintf('fs=%.3e Hz, SPS=%d, beta=%.3f\n',fs,SPS,beta);
fprintf('tau(target)=%.3f, L_FTN=%d -> tau_eff=%.6f\n', ...
    tau_target,L_FTN,tau_eff);
fprintf('CES numerical support=[-%d,+%d] Ts, NfftPulse=%d, KaliasCardinal=%d\n\n', ...
    spanSide,spanSide,NfftPulse,KaliasCardinal);

%% ===================== 2) Design pulses ================================
h_tx = cell(1,nPulse);
Ltarget = 2*spanSide*SPS + 1;

for ip = 1:nPulse
    switch lower(pulseTypes{ip})
        case 'rrc'
            ht = rcosdesign(beta,spanRRC,SPS,'sqrt');
            ht = ht(:);
            ht = ht/sqrt(sum(abs(ht).^2));

        case 'ces'
            ht = designCesPulseFromPhi_N(theta,SPS,spanSide, ...
                                         NfftPulse,KaliasCardinal);
        otherwise
            error('Unknown pulse type.');
    end

    if length(ht) ~= Ltarget
        error('Pulse length mismatch: %d instead of %d.',length(ht),Ltarget);
    end

    h_tx{ip}=ht;
    fprintf('%s: length=%d, energy=%.12f, max|imag|=%.3e\n', ...
        upper(pulseTypes{ip}),length(ht),sum(abs(ht).^2),max(abs(imag(ht))));
end

hces = h_tx{2};
idx0 = (length(hces)+1)/2;
integerOffsets = (-spanSide:spanSide).';
idxInt = idx0 + integerOffsets*SPS;
validInt = idxInt>=1 & idxInt<=length(hces);
idxInt = idxInt(validInt);
integerOffsets = integerOffsets(validInt);
nz = integerOffsets~=0;
cardResidual = max(abs(hces(idxInt(nz)))) / max(abs(hces(idx0)),eps);
fprintf('CES cardinal-zero residual max |p(nTs)|/|p(0)|, n~=0: %.3e\n\n', ...
    cardResidual);

%% ===================== 3) Deterministic spectral metrics ===============
metrics = struct([]);

for ip=1:nPulse
    ht = h_tx{ip};
    label = upper(pulseTypes{ip});

    [H,w] = freqz(ht,1,nfftMetric,'whole');
    H = fftshift(H);
    w = w - pi;
    fHz = w*(fs/(2*pi));

    P0 = abs(H).^2;
    df = fHz(2)-fHz(1);
    Pn = P0/(sum(P0)*df + eps);

    % Full 99%-occupied bandwidth.
    B99full = two_sided_bw_cdf(fHz,Pn,mask);
    Bmain   = B99full/2;   % only the edge used for ACLR integration

    % Gross and net information spectral efficiency.
    RgrossNyq = Rs*k;
    RgrossFTN = RgrossNyq/tau_eff;
    RnetNyq   = Rc*RgrossNyq;
    RnetFTN   = Rc*RgrossFTN;

    SEgrossNyq = RgrossNyq/B99full;
    SEgrossFTN = RgrossFTN/B99full;
    SEnetNyq   = RnetNyq/B99full;
    SEnetFTN   = RnetFTN/B99full;

    % FTN principal cell.
    fcell = fs/(2*L_FTN);
    idxCell = abs(fHz)<=fcell;

    % OC-AER from original pulse spectrum.
    Ein  = sum(Pn(idxCell))*df;
    Eout = sum(Pn(~idxCell))*df;
    OCAER = 10*log10((Eout+eps)/(Ein+eps));

    % Correct folded spectrum: only the L_FTN unique aliases modulo fs.
    Pfold = folded_spectrum_unique(fHz,P0,fs,L_FTN);
    Pcell = Pfold(idxCell);

    Smean = mean(Pcell);
    Smin  = min(Pcell);
    Smax  = max(Pcell);

    ripplePA = 10*log10((Smax+eps)/(Smean+eps));
    Arel = Smin/(Smean+eps);
    Brel = Smax/(Smean+eps);
    kappaSpec = (Smax+eps)/(Smin+eps);
    kappaSpecdB = 10*log10(kappaSpec);

    % ACLR: main band |f|<=B99/2; total two-sided adjacent region
    % B99/2 < |f| <= 3B99/2.
    idxMain = abs(fHz)<=Bmain;
    idxAdj  = abs(fHz)>Bmain & abs(fHz)<=3*Bmain;
    Pmain = sum(Pn(idxMain))*df;
    Padj  = sum(Pn(idxAdj))*df;
    ACLR = 10*log10((Pmain+eps)/(Padj+eps));

    metrics(ip).B99full = B99full;
    metrics(ip).SEgrossNyq = SEgrossNyq;
    metrics(ip).SEgrossFTN = SEgrossFTN;
    metrics(ip).SEnetNyq = SEnetNyq;
    metrics(ip).SEnetFTN = SEnetFTN;
    metrics(ip).OCAER = OCAER;
    metrics(ip).RipplePA = ripplePA;
    metrics(ip).Arel = Arel;
    metrics(ip).Brel = Brel;
    metrics(ip).KappaSpec = kappaSpec;
    metrics(ip).KappaSpecdB = kappaSpecdB;
    metrics(ip).ACLR = ACLR;

    fprintf('%s spectral metrics:\n',label);
    fprintf('  B99(full)       = %.6f MHz\n',B99full/1e6);
    fprintf('  SE gross Nyq/FTN= %.4f / %.4f bit/s/Hz\n',SEgrossNyq,SEgrossFTN);
    fprintf('  SE net   Nyq/FTN= %.4f / %.4f bit/s/Hz\n',SEnetNyq,SEnetFTN);
    fprintf('  OC-AER          = %.3f dB\n',OCAER);
    fprintf('  Fold PA ripple  = %.3f dB\n',ripplePA);
    fprintf('  Arel=min/mean   = %.6e\n',Arel);
    fprintf('  Brel=max/mean   = %.6e\n',Brel);
    fprintf('  kappa_spec      = %.6g (%.3f dB)\n',kappaSpec,kappaSpecdB);
    fprintf('  ACLR             = %.3f dB\n\n',ACLR);

% Define the region to zoom
zoom_xrange = [-0.6 0.6];  % MHz
zoom_yrange = [-1.5 0.5];    % dB

% Convert spectra once
P0_dB    = 10*log10(P0/max(P0) + 1e-14);
Pfold_dB = 10*log10(Pfold/max(Pfold) + 1e-14);

% Main plot
figure;
ax1 = axes;

plot(ax1, fHz/1e6, P0_dB, ...
    'LineWidth',1.5);
hold(ax1,'on');

plot(ax1, fHz/1e6, Pfold_dB, ...
    'LineWidth',1.5);

grid(ax1,'on');
xlabel(ax1,'Frequency (MHz)');
ylabel(ax1,'Power (dB, normalized)');
legend(ax1,'Pulse PSD','Folded spectrum', ...
    'Location','northeast');
title(ax1,sprintf('%s, \\tau=%.2f',label,tau_eff));


%% Draw rectangle showing the zoomed region
rectangle(ax1, ...
    'Position',[zoom_xrange(1), ...
                zoom_yrange(1), ...
                diff(zoom_xrange), ...
                diff(zoom_yrange)], ...
    'EdgeColor','k', ...
    'LineWidth',1.5);


%% Create zoomed inset
ax2 = axes('Position',[0.7 0.25 0.20 0.30]);

plot(ax2, fHz/1e6, P0_dB, ...
    'LineWidth',1.3);
hold(ax2,'on');

plot(ax2, fHz/1e6, Pfold_dB, '--', ...
    'LineWidth',1.3);

% Apply desired zoom
xlim(ax2,zoom_xrange);
ylim(ax2,zoom_yrange);

grid(ax2,'on');
box(ax2,'on');

xlabel(ax2,'MHz');
ylabel(ax2,'dB');

% Make inset easier to see
ax2.LineWidth = 1.2;
ax2.FontSize = 9;
title(ax2, 'Zoom', 'FontWeight', 'bold', 'FontSize', 15);

end

%% ===================== 4) Finite Gram convergence ======================
fprintf('================ GRAM CONVERGENCE ========================\n');
for ip=1:nPulse
    fprintf('%s:\n',upper(pulseTypes{ip}));
    ht=h_tx{ip};

    for ii=1:numel(Klist)
        Kmat=Klist(ii);
        G=gram_matrix_exact_size(ht,L_FTN,Kmat);
        e=real(eig((G+G')/2));
        Ak=min(e);
        Bk=max(e);
        kap=Bk/max(Ak,eps);
        fprintf('  K=%3d : A_K=%11.5e  B_K=%11.5e  kappa_K=%10.4g (%7.3f dB)\n', ...
            Kmat,Ak,Bk,kap,10*log10(kap));
    end

    fprintf('  direct kappa_spec = %10.4g (%7.3f dB)\n\n', ...
        metrics(ip).KappaSpec,metrics(ip).KappaSpecdB);
end

%% ===================== 5) Direct comparison ============================
fprintf('================ CES - SRRC COMPARISON ===================\n');
fprintf('Delta OC-AER (CES-SRRC)     = %+8.3f dB (negative is better)\n', ...
    metrics(2).OCAER-metrics(1).OCAER);
fprintf('Delta fold PA ripple        = %+8.3f dB (negative is better)\n', ...
    metrics(2).RipplePA-metrics(1).RipplePA);
fprintf('Delta ACLR                  = %+8.3f dB (positive is better)\n', ...
    metrics(2).ACLR-metrics(1).ACLR);
fprintf('Gross FTN SE ratio CES/SRRC = %.5f\n', ...
    metrics(2).SEgrossFTN/metrics(1).SEgrossFTN);
fprintf('kappa_spec ratio CES/SRRC   = %.5f\n', ...
    metrics(2).KappaSpec/metrics(1).KappaSpec);
fprintf('Arel ratio CES/SRRC         = %.5f\n', ...
    metrics(2).Arel/metrics(1).Arel);
fprintf('===========================================================\n');

%% =======================================================================
%% SUPPORT FUNCTIONS
%% =======================================================================

function h_tx = designCesPulseFromPhi_N(theta,SPS_sym,spanSideSym,Nfft,Kalias)
Omega_max = pi*SPS_sym;
alpha_vec = theta2alpha(theta);

[phi_t_dense,t_dense] = build_cardinal_phi_N( ...
    alpha_vec,spanSideSym,Omega_max,Nfft,Kalias,SPS_sym);

tT=(-spanSideSym:1/SPS_sym:spanSideSym).';
h_tx=interp1(t_dense,phi_t_dense,tT,'spline',0);
h_tx=h_tx(:);

[~,idx0]=min(abs(tT));
if abs(h_tx(idx0))<1e-14
    error('CES center sample is numerically zero.');
end

% First enforce the interpolation normalization.
h_tx=h_tx/h_tx(idx0);

% Communication-energy normalization. This preserves all cardinal zeros
% but changes the center value from 1 to an energy-normalized constant.
h_tx=h_tx/sqrt(sum(abs(h_tx).^2));
end

function [phi_t,t_sym] = build_cardinal_phi_N( ...
    alpha_vec,spanSideSym,Omega_max,Nfft,Kalias,SPS_sym)

alpha_vec=alpha_vec(:).';
n=(0:Nfft-1).';
dw=2*Omega_max/Nfft;
omega=-Omega_max+n*dw;

beta_hat=compute_beta_hat_N(omega,alpha_vec);

Aomega=zeros(size(omega));
for ka=-Kalias:Kalias
    Aomega=Aomega+compute_beta_hat_N(omega+2*pi*ka,alpha_vec);
end

minDen=min(abs(Aomega));
if minDen<1e-12
    error('Cardinal denominator nearly singular: min|A(omega)|=%.3e.',minDen);
end

phi_hat=beta_hat./Aomega;

dt=2*pi/(Nfft*dw);
phi_time=fftshift(ifft(ifftshift(phi_hat)))*(dw/(2*pi));

m=(-Nfft/2:Nfft/2-1).';
t_full=m*dt;

keep=abs(t_full)<=spanSideSym+2/SPS_sym;
t_sym=t_full(keep);
phi_t=phi_time(keep);
end

function beta_hat=compute_beta_hat_N(omega,alpha_vec)
alpha_vec=alpha_vec(:).';
beta_hat=ones(size(omega));

for n=1:numel(alpha_vec)
    lam=alpha_vec(n);
    z=1i*omega-lam;
    term=(1-exp(-z))./z;
    small=abs(z)<1e-10;
    if any(small)
        zs=z(small);
        term(small)=1-zs/2+zs.^2/6;
    end
    beta_hat=beta_hat.*term;
end
end

function Pfold=folded_spectrum_unique(fHz,P0,fs,L)
% Sum the L unique aliases modulo fs. The common scale factor 1/L is not
% needed for ripple, Arel/Brel, or kappa because those are scale invariant.
Pfold=zeros(size(P0));
falias=fs/L;

for m=0:L-1
    fshift=fHz-m*falias;
    fwrap=wrapToInterval(fshift,-fs/2,fs/2);
    Pfold=Pfold+interp1(fHz,P0,fwrap,'linear','extrap');
end

Pfold=max(real(Pfold),0);
end

function G=gram_matrix_exact_size(p,L,K)
% K is the ACTUAL matrix dimension.
p=p(:);
N=length(p);
r=zeros(K,1);

for lag=0:K-1
    s=lag*L;
    if s>=N
        r(lag+1)=0;
    else
        r(lag+1)=sum(p(1+s:N).*conj(p(1:N-s)));
    end
end

G=toeplitz(r,conj(r));
G=(G+G')/2;
end

function BW=two_sided_bw_cdf(f,PSD,mask)
df=f(2)-f(1);
PSD=PSD/(sum(PSD)*df+eps);
cdf=cumsum(PSD)*df;

low=(1-mask)/2;
high=1-low;

iL=find(cdf>=low,1,'first');
iU=find(cdf>=high,1,'first');

BW=abs(f(iU)-f(iL));
end

function y=wrapToInterval(x,minVal,maxVal)
L=maxVal-minVal;
y=x-L*floor((x-minVal)/L);
end

function alpha_vec=theta2alpha(theta)
theta=theta(:).';
if mod(numel(theta),2)~=0
    error('theta must be [sigma1 omega1 ... sigmaP omegaP].');
end

P=numel(theta)/2;
alpha_vec=zeros(1,2*P);

for i=1:P
    sigma=theta(2*i-1);
    omega=theta(2*i);
    alpha_vec(2*i-1)= sigma+1j*omega;
    alpha_vec(2*i)  =-sigma-1j*omega;
end
end
