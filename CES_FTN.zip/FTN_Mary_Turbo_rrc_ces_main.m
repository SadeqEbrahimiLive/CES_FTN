%% FTN_Mary_Turbo_rrc_ces_main.m
% FTN Turbo Equalization with generic M-QAM / M-PSK
% Pulses: SRRC and CES
% Includes FTN ISI analysis, folded spectrum, Forney spectral factor,
% reduced-memory BCJR detection, turbo decoding, and spectral efficiency.
%
% Requires:
%   - FTN_Mary_BCJR_Equalizer.m
%   - Siso_Conv_Decoder_r12.m
%

clear; clc; close all;
rng(123,'twister');

%% ===================== 1. System parameters =============================
% ================= Rates and sampling and Modulation =====================
modType = 'qam';
M       = 8;
k       = log2(M);
Rc      = 1/2;

Rs      = 1e6;              % nominal symbol rate [sym/s]
RbGross = Rs*k;              % gross coded-bit rate at tau=1 [bit/s]
RbInfo  = Rc*RbGross;        % net information-bit rate at tau=1 [bit/s]
Tsym    = 1/Rs;

SPS     = 10;
fs      = SPS*Rs;
tau     = 0.7;
L_FTN   = round(tau*SPS);
tauEff  = L_FTN/SPS;

% ========================== Pulse parameters =============================
spanSide = 8;
spanSRRC = 2*spanSide;
beta     = 0.15;  % bandwidth-matched SRRC reference

% New tau=0.7 CES pole set:
% theta = [sigma1 omega1 sigma2 omega2 sigma3 omega3]
theta = [ -0.687894 -1.093351 -0.988055 1.690138 -0.116332 -2.664607 ];

pulseTypes = {'srrc','ces'};
nPulse     = numel(pulseTypes);

% ===================== Turbo code and receiver ===========================
trellis = poly2trellis(3,[4 7]);
Imax    = 5;

% Reduced-memory detector is intentionally fixed at Lch=3.
% For 8-QAM this gives 8^3 = 512 BCJR states.
Lch = 3;

EbN0dB_vec = 0:2:14;
nSNR       = numel(EbN0dB_vec);

% Monte-Carlo stopping for the final BER validation.
% Low/mid-SNR points terminate quickly after minErrsFinal is reached;
% high-SNR points may run up to maxInfoBits.
infoBitsPerFrame = 3000;
minErrsFinal     = 200;
maxInfoBits      = 1e6;

if mod(2*infoBitsPerFrame,k)~=0
    error('2*infoBitsPerFrame must be divisible by log2(M).');
end

% Spectral factor settings
NfftFactor       = 16384;
spectralFloorRel = 1e-12;
factorEnergyKeep = 1-1e-8;
maxFactorTaps    = 128;

% Spectral metric settings: match the optimizer exactly.
metricMask        = 0.99;
NfftMetrics       = 16384;

% Decoder-to-equalizer feedback damping.
% Keep 1.0 unless the iteration trajectory clearly oscillates.
feedbackDamping = 1.0;

fprintf('Rs = %.3e sym/s, gross Rb = %.3e bit/s, net Rb = %.3e bit/s\n', ...
    Rs,RbGross,RbInfo);
fprintf('fs = %.3e Hz, SPS = %d, tau = %.3f, L_FTN = %d samples\n', ...
    fs,SPS,tauEff,L_FTN);
fprintf('Modulation: %s, M=%d, k=%d, Rc=%.3f\n',upper(modType),M,k,Rc);
fprintf('BCJR detector memory Lch=%d (%d states)\n',Lch,M^Lch);

mapping = create_mapping_struct(modType,M);

%% ===================== 2. Storage =======================================
BER_turbo = nan(nSNR,Imax,nPulse);
NbitsBER  = zeros(nSNR,nPulse);
NerrBER   = zeros(nSNR,Imax,nPulse);

h_tx_cell   = cell(1,nPulse);
h_det_cell  = cell(1,nPulse);
h_full_cell = cell(1,nPulse);
spec = struct();

%% ===================== 3. Pulse analysis ================================
for ip=1:nPulse
    ptype = pulseTypes{ip};
    fprintf('\n======================================\n');
    fprintf(' Pulse type: %s\n',upper(ptype));
    fprintf('======================================\n');

    %% 3.1 TX pulse design
    switch lower(ptype)
        case 'srrc'
            h_tx = rcosdesign(beta,spanSRRC,SPS,'sqrt').';
        case 'ces'
            % EXACT same cardinal CES construction used by the optimizer.
            h_tx = designCesPulseFromPhi_generalN(theta,SPS,spanSide);
        otherwise
            error('Unknown pulse type.');
    end

    h_tx = h_tx(:);
    h_tx = h_tx/sqrt(sum(abs(h_tx).^2));
    h_tx_cell{ip}=h_tx;

    fprintf('Pulse length=%d, energy=%.12f, max|imag|=%.3e\n', ...
        length(h_tx),sum(abs(h_tx).^2),max(abs(imag(h_tx))));

    if strcmpi(ptype,'ces')
        cardResid = cardinal_zero_residual(h_tx,SPS,spanSide);
        fprintf('CES cardinal-zero residual max |p(nTs)|/|p(0)|, n~=0: %.3e\n',cardResid);
    else
        cardResid = NaN;
    end

    %% 3.2 Raw FTN autocorrelation / ISI
    Kmax = floor((length(h_tx)-1)/L_FTN);
    [gpos,~,mainPow,isiPow,mainIsi_dB] = ...
        sampled_autocorr(h_tx,L_FTN,Kmax);

    fprintf('Autocorrelation taps g[k], k=0..min(7,Kmax):\n');
    disp(gpos(1:min(8,numel(gpos))).');
    fprintf('main power = %.6g, total off-center ISI power = %.6g, main/ISI = %.2f dB\n', ...
        mainPow,isiPow,mainIsi_dB);

    %% 3.3 Spectral metrics: EXACT optimizer definitions
    met = evaluate_pulse_metrics(h_tx,fs,RbGross,RbInfo,tauEff, ...
        L_FTN,NfftMetrics,metricMask);

    fprintf('B99(full)       = %.6f MHz\n',met.BW99/1e6);
    fprintf('SE gross Nyq/FTN= %.4f / %.4f bit/s/Hz\n',RbGross/met.BW99,met.SE_gross);
    fprintf('SE net   Nyq/FTN= %.4f / %.4f bit/s/Hz\n',RbInfo/met.BW99,met.SE_net);
    fprintf('OC-AER          = %.3f dB\n',met.OCAER_dB);
    fprintf('Fold PA ripple  = %.3f dB\n',met.RipplePA_dB);
    fprintf('Arel=min/mean   = %.6e\n',met.Arel);
    fprintf('Brel=max/mean   = %.6e\n',met.Brel);
    fprintf('kappa_inf/spec  = %.6g (%.3f dB)\n',met.kappa_spec,met.DynRange_dB);

    %% 3.4 Minimum-phase spectral factor / reduced-memory detector
    [fFactor,~,SrawMin,SrawMax] = minphase_factor_from_gpos( ...
        gpos,NfftFactor,spectralFloorRel);

    [h_full,capturedFull] = ...
        truncate_factor_energy(fFactor,factorEnergyKeep,maxFactorTaps);

    h_det = h_full(1:min(Lch+1,numel(h_full)));
    if numel(h_det)<Lch+1
        h_det(end+1:Lch+1)=0;
    end

    captureDet = sum(abs(h_det).^2)/sum(abs(h_full).^2);
    residualDet = max(0,1-captureDet);
    kappaFactor = SrawMax/max(SrawMin,realmin);
    kappaMismatchPct = 100*abs(kappaFactor-met.kappa_spec)/max(met.kappa_spec,realmin);

    fprintf('Forney spectral factor: raw Smin=%.4e, Smax=%.4e, max/min=%.6g (%.3f dB)\n', ...
        SrawMin,SrawMax,kappaFactor,10*log10(kappaFactor));
    fprintf('Direct-fold vs Forney kappa difference = %.3f%%\n',kappaMismatchPct);
    fprintf('Factor simulation taps=%d (captured %.8f of spectral-factor energy)\n', ...
        numel(h_full),capturedFull);
    fprintf('BCJR uses %d taps (Lch=%d), captures %.3f%%; residual tail = %.3f%%\n', ...
        numel(h_det),Lch,100*captureDet,100*residualDet);
    fprintf('Detector taps h_det:\n');
    disp(h_det(:).');

    if kappaMismatchPct > 5
        warning('%s folded-spectrum and Forney-factor condition ratios differ by %.1f%%.', ...
            upper(ptype),kappaMismatchPct);
    end
    if captureDet < 0.95
        warning('%s BCJR memory captures only %.1f%% of factor energy. Describe as reduced-memory BCJR.', ...
            upper(ptype),100*captureDet);
    end

    h_full_cell{ip}=h_full;
    h_det_cell{ip}=h_det;

    % Store all diagnostics for plotting/comparison.
    spec(ip).fPSD=met.f;
    spec(ip).Pn=met.Pow/max(met.Pow);
    spec(ip).B99=met.BW99;
    spec(ip).fFold=met.fold_f;
    spec(ip).SfoldNorm=met.fold_norm;
    spec(ip).OCAER_dB=met.OCAER_dB;
    spec(ip).RipplePA_dB=met.RipplePA_dB;
    spec(ip).Arel=met.Arel;
    spec(ip).Brel=met.Brel;
    spec(ip).kappaSpec=met.kappa_spec;
    spec(ip).DynRange_dB=met.DynRange_dB;
    spec(ip).SEgross=met.SE_gross;
    spec(ip).SEnet=met.SE_net;
    spec(ip).isiPow=isiPow;
    spec(ip).mainIsi_dB=mainIsi_dB;
    spec(ip).captureDet=captureDet;
    spec(ip).residualDet=residualDet;
    spec(ip).cardinalResidual=cardResid;
    spec(ip).kappaFactor=kappaFactor;
end

%% ===================== 3.5 CES-SRRC diagnostic summary ==================
if nPulse==2 && strcmpi(pulseTypes{1},'srrc') && strcmpi(pulseTypes{2},'ces')
    fprintf('\n================ CES - SRRC SUMMARY ======================\n');
    fprintf('SRRC beta                         = %.3f\n',beta);
    fprintf('Delta B99 (CES-SRRC)             = %+9.6f MHz\n', ...
        (spec(2).B99-spec(1).B99)/1e6);
    fprintf('Gross FTN SE ratio CES/SRRC      = %.6f\n',spec(2).SEgross/spec(1).SEgross);
    fprintf('Delta OC-AER (CES-SRRC)          = %+9.3f dB (negative is better)\n', ...
        spec(2).OCAER_dB-spec(1).OCAER_dB);
    fprintf('Delta fold PA ripple             = %+9.3f dB (negative is better)\n', ...
        spec(2).RipplePA_dB-spec(1).RipplePA_dB);
    fprintf('kappa_inf ratio CES/SRRC         = %.6f\n',spec(2).kappaSpec/spec(1).kappaSpec);
    fprintf('Arel ratio CES/SRRC              = %.6f\n',spec(2).Arel/spec(1).Arel);
    fprintf('Total ISI-energy ratio CES/SRRC  = %.6f\n',spec(2).isiPow/spec(1).isiPow);
    fprintf('4-tap factor capture SRRC/CES    = %.3f%% / %.3f%%\n', ...
        100*spec(1).captureDet,100*spec(2).captureDet);
    fprintf('Residual factor tail SRRC/CES    = %.3f%% / %.3f%%\n', ...
        100*spec(1).residualDet,100*spec(2).residualDet);
    fprintf('===========================================================\n');
end

%% ===================== 4. Fig. 2: PSD + folded spectrum =================
figure('Color','w');
for ip=1:nPulse
    subplot(2,1,ip);
    plot(spec(ip).fPSD/1e6,10*log10(spec(ip).Pn+1e-14),'LineWidth',1.2); hold on;

    Sf = spec(ip).SfoldNorm/max(spec(ip).SfoldNorm);
    plot(spec(ip).fFold/1e6,10*log10(Sf+1e-14),'--','LineWidth',1.5);

    grid on;
    xlim([-2.5 2.5]);
    ylim([-90 3]);
    xlabel('Frequency (MHz)');
    ylabel('Normalized power (dB)');
    title(sprintf('%s: PSD and FTN folded spectrum, \\tau=%.2f',upper(pulseTypes{ip}),tauEff));
    legend('Pulse |H(f)|^2','Folded spectrum','Location','best');
end

%% ===================== 5. BER Monte Carlo ===============================
for ip=1:nPulse
    ptype = pulseTypes{ip};
    h_full = h_full_cell{ip};
    h_det  = h_det_cell{ip};

    residualEnergy = max(0,sum(abs(h_full).^2)-sum(abs(h_det).^2));

    for iSNR=1:nSNR
        EbN0dB = EbN0dB_vec(iSNR);
        EbN0lin=10^(EbN0dB/10);
        fprintf('\n[%s] Eb/N0 = %.1f dB\n',upper(ptype),EbN0dB);

        % Same random realization for both pulse types at each Eb/N0.
        rng(10000+iSNR,'twister');

        errCount=zeros(Imax,1);
        bitCount=0;
        frame=0;

        while (errCount(end)<minErrsFinal) && (bitCount<maxInfoBits)
            frame=frame+1;

            Kinfo=min(infoBitsPerFrame,maxInfoBits-bitCount);
            while mod(2*Kinfo,k)~=0
                Kinfo=Kinfo-1;
            end
            if Kinfo<=0
                break;
            end

            Ns=2*Kinfo/k;

            %% 5.1 Systematic rate-1/2 convolutional encoding
            u=randi([0 1],Kinfo,1);
            uPad=[0;0;u];
            v=mod(uPad(3:end)+uPad(2:end-1)+uPad(1:end-2),2);

            coded=zeros(2*Kinfo,1);
            coded(1:2:end)=u;
            coded(2:2:end)=v;

            posSys=1:2:2*Kinfo;
            posPar=2:2:2*Kinfo;

            %% 5.2 Bit interleaving + M-ary mapping
            piBits=randperm(2*Kinfo);
            piDeint=zeros(1,2*Kinfo);
            piDeint(piBits)=1:2*Kinfo;

            codedInt=coded(piBits);
            bitsSym=reshape(codedInt,k,Ns).';

            symTx=zeros(Ns,1);
            for n=1:Ns
                idxSym=find(all(mapping.bits==bitsSym(n,:),2),1,'first');
                symTx(n)=mapping.constellation(idxSym);
            end

            EsTx=mean(abs(symTx).^2);
            EbInfo=EsTx/(Rc*k);
            N0=EbInfo/EbN0lin;

            %% 5.3 Full causal Forney-factor channel + warm-up
            Npre=max(20,numel(h_full)+Lch);
            preIdx=randi([1 M],Npre,1);
            preSym=mapping.constellation(preIdx);
            preSym=preSym(:);

            x=[preSym; symTx];
            yAll=filter(h_full,1,x);
            yClean=yAll(Npre+1:Npre+Ns);

            noise=sqrt(N0/2)*(randn(Ns,1)+1j*randn(Ns,1));
            y=yClean+noise;

            % The unmodeled factor tail remains present in y.  Its average
            % energy is included in the reduced-memory branch uncertainty.
            noiseVarEff=N0 + EsTx*residualEnergy;

            %% 5.4 Turbo iterations
            % A-priori coded-bit LLRs in UNINTERLEAVED order.
            L_a_bits=zeros(2*Kinfo,1);

            for iter=1:Imax
                % Interleave decoder feedback for the M-ary equalizer.
                L_a_int_vec=L_a_bits(piBits);
                L_a_int=reshape(L_a_int_vec,k,Ns).';

                % SISO M-ary BCJR equalizer.
                L_e_eq_int=FTN_Mary_BCJR_Equalizer( ...
                    y,h_det,noiseVarEff,mapping,L_a_int,iter);

                % Back to original coded-bit order.
                L_e_eq_vec=reshape(L_e_eq_int.',[],1);
                L_e_eq=L_e_eq_vec(piDeint);

                L_eq_sys=L_e_eq(posSys);
                L_eq_par=L_e_eq(posPar);

                % The equalizer outputs are already EXTRINSIC, therefore
                % no old decoder feedback is inserted again here.
                L_a_dec=zeros(Kinfo,1);

                [L_dec_ext_sys,L_dec_ext_par,L_dec_post] = ...
                    Siso_Conv_Decoder_r12( ...
                    L_eq_sys,L_eq_par,L_a_dec,trellis,iter);

                % IMPORTANT CHANGE: feed back BOTH systematic and parity
                % decoder-extrinsic information to the M-ary equalizer.
                L_a_bits_new=zeros(2*Kinfo,1);
                L_a_bits_new(posSys)=feedbackDamping*L_dec_ext_sys;
                L_a_bits_new(posPar)=feedbackDamping*L_dec_ext_par;
                L_a_bits=L_a_bits_new;

                uHat=double(L_dec_post<0);  % L=log(P0/P1)
                errCount(iter)=errCount(iter)+sum(uHat~=u);
            end

            bitCount=bitCount+Kinfo;

            if frame==1 || mod(frame,10)==0
                fprintf('  frame=%d, bits=%d, final errors=%d, BER~%.3g\n', ...
                    frame,bitCount,errCount(end),errCount(end)/bitCount);
            end
        end

        BER_turbo(iSNR,:,ip)=errCount.'/max(bitCount,1);
        NbitsBER(iSNR,ip)=bitCount;
        NerrBER(iSNR,:,ip)=errCount.';

        fprintf('  FINAL: bits=%d, errors by iter=',bitCount);
        fprintf(' %d',errCount);
        fprintf('\n');
        fprintf('         BER by iter   =');
        fprintf(' %.4g',BER_turbo(iSNR,:,ip));
        fprintf('\n');

        if errCount(end)==0
            fprintf('         zero errors: 95%% upper bound approximately %.3g (3/N)\n', ...
                3/max(bitCount,1));
        end
    end
end

%% ===================== 6. Fig. 3: BER ===================================
figure('Color','w');
hold on;

markers = {'s','o'};
styles  = {'-','-.'};
lineHandles = gobjects(1,nPulse);

for ip = 1:nPulse

    b = squeeze(BER_turbo(:,Imax,ip));
    bPlot = b;

    % Never plot zero measured errors as BER = 0 on a logarithmic axis.
    % Use the rule-of-three 95% upper confidence bound instead.
    zeroIdx = (squeeze(NerrBER(:,Imax,ip)) == 0);

    for q = find(zeroIdx).'
        bPlot(q) = 3 / max(NbitsBER(q,ip),1);
    end

    lineHandles(ip)=semilogy(EbN0dB_vec,bPlot,styles{ip}, ...
        'Marker',markers{ip},'LineWidth',1.8,'MarkerSize',7);

    % Overlay zero-error points with downward triangles to denote upper bounds.
    if any(zeroIdx)
        semilogy(EbN0dB_vec(zeroIdx),bPlot(zeroIdx),'v', ...
            'LineStyle','none','Color',lineHandles(ip).Color, ...
            'MarkerSize',8,'LineWidth',1.3,'HandleVisibility','off');
    end
end

ax = gca;
ax.YScale = 'log';
grid on;
box on;
xlim([min(EbN0dB_vec) max(EbN0dB_vec)]);
ylim([1e-6 3e-1]);
yticks([1e-6 1e-5 1e-4 1e-3 1e-2 1e-1]);
ax.YMinorGrid = 'on';
ax.XMinorGrid = 'off';
ax.FontSize = 12;
ax.FontWeight = 'bold';
ax.LineWidth = 1.1;

xlabel('$E_b/N_0$ (dB)','Interpreter','latex','FontSize',14);
ylabel('Post-decoder BER','FontSize',14);
legend(lineHandles,{'SRRC','CES'},'Location','southwest','FontSize',11);

title(sprintf(['8-QAM, $R_c=1/2$, $\\tau=%.2f$, ', ...
               '$L_{\\mathrm{ch}}=%d$, %d turbo iterations'], ...
               tauEff,Lch,Imax), ...
      'Interpreter','latex','FontSize',13);

hold off;

fprintf('\nDone.\n');

%% ======================================================================
%% SUPPORT FUNCTIONS
%% ======================================================================
function mapping=create_mapping_struct(modType,M)
k=log2(M);
symIdx=(0:M-1).';

switch lower(modType)
    case 'qam'
        const=qammod(symIdx,M,'gray','UnitAveragePower',true);
    case 'psk'
        const=pskmod(symIdx,M,0,'gray');
    otherwise
        error('Unsupported modulation type.');
end

mapping.M=M;
mapping.bitsPerSym=k;
mapping.constellation=const(:).';
mapping.bits=de2bi(symIdx,k,'left-msb');
end

%% ======================================================================
function [gpos,gfull,mainPow,isiPow,ratio_dB]=sampled_autocorr(h,L,Kmax)
h=h(:);
gpos=zeros(Kmax+1,1);

for kk=0:Kmax
    sh=kk*L;
    if sh < length(h)
        gpos(kk+1)=sum(h(1+sh:end).*conj(h(1:end-sh)));
    end
end

gfull=[conj(flipud(gpos(2:end))); gpos];
mainPow=abs(gpos(1))^2;
isiPow=2*sum(abs(gpos(2:end)).^2);
ratio_dB=10*log10(mainPow/max(isiPow,realmin));
end

%% ======================================================================
function met = evaluate_pulse_metrics(p,fs,Rb_gross,Rb_net,rho,L_ftn,nfft,mask)
% Same spectral-metric definitions as pareto_ces_OC_Ripple_corrected.m.
p = p(:);
p = p/sqrt(sum(abs(p).^2));

[H,w] = freqz(p,1,nfft,'whole');
H = fftshift(H);
w = w-pi;
f = w*(fs/(2*pi));
Pow = abs(H).^2;
df = f(2)-f(1);
Pow = Pow/(sum(Pow)*df + eps);

% FULL 99%-occupied bandwidth: same CDF definition used in the optimizer.
BW99 = two_sided_bw_cdf(f,Pow,mask);
SE_gross = (Rb_gross/rho)/BW99;
SE_net = (Rb_net/rho)/BW99;

% Out-of-cell alias energy relative to the FTN Nyquist cell.
f_alias = fs/L_ftn;
fcell = f_alias/2;
Ein = sum(Pow(abs(f)<=fcell))*df;
Eout = sum(Pow(abs(f)>fcell))*df;
OCAER_dB = 10*log10((Eout+eps)/(Ein+eps));

% Folded spectrum: exactly L_ftn unique aliases modulo fs.
Nfold = max(2048,2^nextpow2(4*nfft/L_ftn));
fold_f = linspace(-f_alias/2,f_alias/2,Nfold).';
Sfold = zeros(size(fold_f));
for r = 0:L_ftn-1
    fshift = fold_f + r*f_alias;
    fwrap = wrapToInterval(fshift,-fs/2,fs/2);
    Sfold = Sfold + interp1(f,Pow,fwrap,'linear',0);
end
Sfold = Sfold/L_ftn;

Smean = mean(Sfold);
Smin = min(Sfold);
Smax = max(Sfold);
Arel = Smin/(Smean+eps);
Brel = Smax/(Smean+eps);
if Smin <= 0
    kappa_spec = inf;
else
    kappa_spec = Smax/Smin;
end
DynRange_dB = 10*log10(kappa_spec);
RipplePA_dB = 10*log10(Smax/(Smean+eps));

met = struct;
met.BW99 = BW99;
met.SE_gross = SE_gross;
met.SE_net = SE_net;
met.OCAER_dB = OCAER_dB;
met.RipplePA_dB = RipplePA_dB;
met.Smin = Smin;
met.Smax = Smax;
met.Arel = Arel;
met.Brel = Brel;
met.kappa_spec = kappa_spec;
met.DynRange_dB = DynRange_dB;
met.fold_f = fold_f;
met.fold_norm = Sfold/(Smean+eps);
met.f = f;
met.Pow = Pow;
end

%% ======================================================================
function BW = two_sided_bw_cdf(f,PSD,mask)
df = f(2)-f(1);
PSD = PSD/(sum(PSD)*df + eps);
cdfv = cumsum(PSD)*df;
low = (1-mask)/2;
high = 1-low;
iL = find(cdfv>=low,1,'first');
iU = find(cdfv>=high,1,'first');
if isempty(iL) || isempty(iU)
    BW = NaN;
else
    BW = abs(f(iU)-f(iL));
end
end

%% ======================================================================
function [fFactor,S,Smin,Smax]=minphase_factor_from_gpos(gpos,Nfft,floorRel)
% Minimum-phase spectral factor of the sampled autocorrelation sequence:
% S(omega)=sum_k g[k]e^{-j omega k}=|F(e^{j omega})|^2.

gpos=gpos(:);
K=length(gpos)-1;
w=2*pi*(0:Nfft-1).'/Nfft;

S=real(gpos(1))*ones(Nfft,1);
for kk=1:K
    S=S+2*real(gpos(kk+1)*exp(-1j*w*kk));
end

Smin=min(S);
Smax=max(S);
Sreg=max(S,max(Smax*floorRel,realmin));

c=real(ifft(log(Sreg)));
cmin=zeros(Nfft,1);
cmin(1)=0.5*c(1);

if mod(Nfft,2)==0
    cmin(2:Nfft/2)=c(2:Nfft/2);
    cmin(Nfft/2+1)=0.5*c(Nfft/2+1);
else
    cmin(2:(Nfft+1)/2)=c(2:(Nfft+1)/2);
end

F=exp(fft(cmin));
fFactor=ifft(F);
fFactor=fFactor*exp(-1j*angle(fFactor(1)));
end

%% ======================================================================
function [hKeep,captured]=truncate_factor_energy(f,target,maxTaps)
f=f(:);
Etot=sum(abs(f).^2);
cum=cumsum(abs(f).^2)/Etot;
idx=find(cum>=target,1,'first');
if isempty(idx)
    idx=maxTaps;
end
idx=min(idx,maxTaps);
hKeep=f(1:idx);
captured=sum(abs(hKeep).^2)/Etot;
end

%% ======================================================================
function r = cardinal_zero_residual(p,SPS,spanSide)
% Numerical cardinality diagnostic on nominal symbol-spaced samples.
p=p(:);
center=(length(p)+1)/2;
if abs(center-round(center))>1e-12
    error('Cardinal residual expects an odd-length pulse.');
end
center=round(center);
n=(-spanSide:spanSide).';
idx=center+n*SPS;
valid=idx>=1 & idx<=length(p);
n=n(valid); idx=idx(valid);
i0=find(n==0,1,'first');
if isempty(i0) || abs(p(idx(i0)))<realmin
    r=inf;
    return;
end
nz=(n~=0);
if ~any(nz)
    r=0;
else
    r=max(abs(p(idx(nz))))/abs(p(idx(i0)));
end
end

%% ======================================================================
function p = designCesPulseFromPhi_generalN(theta,SPS,span)
% EXACT copy of the corrected optimizer's CES realization.
Nfft_design = 8192;
Om = pi*SPS;
Kalias = 20;
alpha = theta2alpha(theta);
[phi,~] = build_cardinal_phi_N(alpha,span,Om,Nfft_design,Kalias);
p = phi(:);
if any(~isfinite(p)) || norm(p)==0
    error('Invalid CES pulse produced.');
end
p = p/sqrt(sum(abs(p).^2));
end

%% ======================================================================
function [phi,t] = build_cardinal_phi_N(lambda,span,Om,Nfft,K)
n = (0:Nfft-1).';
dw = 2*Om/Nfft;
w = -Om+n*dw;

beta = compute_beta_hat_N(w,lambda);
A = zeros(size(w));
for kk = -K:K
    A = A + compute_beta_hat_N(w+2*pi*kk,lambda);
end

scaleA = max(abs(A));
if ~isfinite(scaleA) || scaleA==0
    error('Cardinal denominator is numerically invalid.');
end
if min(abs(A)) < 1e-10*scaleA
    error('Cardinal denominator nearly singular for this pole set.');
end

phi_hat = beta./A;
phi = fftshift(ifft(ifftshift(phi_hat)))*(dw/(2*pi));

dt = 2*pi/(Nfft*dw); % = 1/SPS because Om=pi*SPS
m = (-Nfft/2:Nfft/2-1).';
t = m*dt;

idx = abs(t)<=span;
phi = phi(idx);
t = t(idx);

[~,i0] = min(abs(t));
if abs(phi(i0)) < 1e-12
    error('CES cardinal sample at t=0 is too small.');
end
phi = phi/phi(i0);
end

%% ======================================================================
function b = compute_beta_hat_N(w,lambda)
b = ones(size(w));
for ll = 1:numel(lambda)
    lam = lambda(ll);
    z = 1i*w-lam;
    term = (1-exp(-z))./z;
    near0 = abs(z)<1e-10;
    if any(near0)
        % Removable singularity: (1-exp(-z))/z = 1-z/2+z^2/6+...
        term(near0) = 1-z(near0)/2+z(near0).^2/6;
    end
    b = b.*term;
end
end

%% ======================================================================
function alpha = theta2alpha(theta)
% theta=[sigma1 omega1 sigma2 omega2 ...]
% Generates opposite-sign pole pairs {alpha,-alpha}.
theta=theta(:).';
if mod(numel(theta),2)~=0
    error('theta must contain [sigma1 omega1 ...].');
end
P=numel(theta)/2;
alpha=zeros(1,2*P);
for ii=1:P
    sigma=theta(2*ii-1);
    omega=theta(2*ii);
    a=sigma+1j*omega;
    alpha(2*ii-1)=a;
    alpha(2*ii)=-a;
end
end

%% ======================================================================
function y = wrapToInterval(x,minVal,maxVal)
L = maxVal-minVal;
y = x-L.*floor((x-minVal)./L);
y(y>=maxVal)=minVal;
end
