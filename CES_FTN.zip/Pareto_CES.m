%% Pareto_CES.m
% Pareto exploration for Cardinal Exponential Spline (CES) FTN pulses
%

clear; clc; close all;
rng(123);

%% =================== 1) System parameters =============================
M = 8;                          % 8-QAM
k = log2(M);                    % 3 bits/coded symbol
Rs = 1e6;                       % nominal symbol rate [sym/s]
Rb_gross = Rs*k;                % gross coded bit rate [bit/s]
Rc = 1/2;                       % code rate (for optional net-SE reporting)
Rb_net = Rc*Rb_gross;           % information bit rate [bit/s]

spanSide = 8;                   % numerical one-sided pulse span [symbols]
SPS = 10;                       % samples per nominal symbol
fs = SPS*Rs;                    % sample rate [Hz]

tau_target = 0.7;              % choose 0.6, 0.7, or 0.8
L_ftn = round(tau_target*SPS);  % FTN spacing [samples]
rho_eff = L_ftn/SPS;            % actually realized packing factor

mask = 0.99;                    % occupied-power fraction
nfft = 16384;                   % spectral evaluation FFT size

beta_roll = 0.05;               % reference SRRC roll-off (baseline only)
spanSRRC = 2*spanSide;          % rcosdesign total span in symbols

fprintf('M=%d (%d bits/symbol), Rs=%.3e sym/s, gross Rb=%.3e bit/s\n', ...
    M,k,Rs,Rb_gross);
fprintf('tau target=%.3f, realized rho=%.3f, L_FTN=%d samples, SPS=%d\n', ...
    tau_target,rho_eff,L_ftn,SPS);

%% =================== 2) Stability/spectral constraints ================
if abs(rho_eff-0.6) < 1e-12
    kappa_max = 1e5;
    OCAER_max_dB = -50;
    Ripple_max_dB = 2.5;
elseif abs(rho_eff-0.7) < 1e-12
    kappa_max = 1e4;
    OCAER_max_dB = -50;
    Ripple_max_dB = 1.9;
elseif abs(rho_eff-0.8) < 1e-12
    kappa_max = 1e3;
    OCAER_max_dB = -45;
    Ripple_max_dB = 1.5;
else
    kappa_max = 1e4;
    OCAER_max_dB = -50;
    Ripple_max_dB = 1.9;
end

% If the folded-ripple definition makes the previous hard ripple
% threshold too restrictive, set this false and keep ripple as a Pareto
% objective only. This is useful for the first diagnostic rerun.
useRippleConstraint = true;

fprintf('Constraints: kappa_max=%.6g, OC-AER<=%.2f dB, ripple<=%.2f dB\n', ...
    kappa_max,OCAER_max_dB,Ripple_max_dB);

%% =================== 3) CES pole search ================================
N_poles = 6;                    % TOTAL number of poles; must be even
Ppair = N_poles/2;              % number of opposite-sign pole pairs
N_rand = 5000;

sigma_min = -1; sigma_max = 1;
omega_min = -pi;  omega_max = pi;

% Final Pareto-point selection rule:
% among Pareto candidates within 0.5% of the maximum Pareto SE,
% select the candidate with the smallest direct folded-spectrum kappa_spec.
SE_selection_tol = 0.005;

fprintf('CES search: N=%d total poles (%d opposite-sign pairs), Nrand=%d\n', ...
    N_poles,Ppair,N_rand);
fprintf('Search ranges: sigma in [%.3f, %.3f], omega in [%.3f, %.3f] rad\n', ...
    sigma_min,sigma_max,omega_min,omega_max);

%% =================== 4) SRRC reference ================================
p_srrc = rcosdesign(beta_roll, spanSRRC, SPS, 'sqrt').';
p_srrc = p_srrc/sqrt(sum(abs(p_srrc).^2));

metSRRC = evaluate_pulse_metrics(p_srrc,fs,Rb_gross,Rb_net,rho_eff, ...
    L_ftn,nfft,mask);

fprintf('\nSRRC beta=%.3f reference:\n',beta_roll);
fprintf('  B99(full)=%.6f MHz | SEgross=%.4f | SEnet=%.4f bit/s/Hz\n', ...
    metSRRC.BW99/1e6,metSRRC.SE_gross,metSRRC.SE_net);
fprintf('  OC-AER=%.3f dB | Fold PA ripple=%.3f dB\n', ...
    metSRRC.OCAER_dB,metSRRC.RipplePA_dB);
fprintf('  Fold min/mean=%.4e | max/mean=%.4e | kappa_spec=%.4g (%.3f dB)\n\n', ...
    metSRRC.Arel,metSRRC.Brel,metSRRC.kappa_spec,metSRRC.DynRange_dB);

%% =================== 5) Storage =======================================
theta_all = zeros(N_rand,2*Ppair);
SE_vals = NaN(N_rand,1);
OCAER_vals = NaN(N_rand,1);
Ripple_vals = NaN(N_rand,1);
Arel_vals = NaN(N_rand,1);
Brel_vals = NaN(N_rand,1);
kappaSpec_vals = NaN(N_rand,1);
DynRange_vals = NaN(N_rand,1);
BW_vals = NaN(N_rand,1);
valid = false(N_rand,1);
nFail = 0;
nRejectKappa = 0;
nRejectOCAER = 0;
nRejectRipple = 0;

%% =================== 6) Random sampling ================================
fprintf('Sampling %d CES candidates...\n',N_rand);

for n = 1:N_rand
    theta = zeros(1,2*Ppair);
    for ii = 1:Ppair
        theta(2*ii-1) = sigma_min + (sigma_max-sigma_min)*rand;
        theta(2*ii)   = omega_min + (omega_max-omega_min)*rand;
    end
    theta_all(n,:) = theta;

    try
        p = designCesPulseFromPhi_generalN(theta,SPS,spanSide);
        met = evaluate_pulse_metrics(p,fs,Rb_gross,Rb_net,rho_eff, ...
            L_ftn,nfft,mask);

        % Stability constraint: kappa_inf = B_tau/A_tau <= kappa_max.
        % No separate A_tau >= A_min constraint is required. If A_tau=0,
        % kappa_spec becomes Inf and the candidate is rejected here.
        if ~isfinite(met.kappa_spec) || met.kappa_spec > kappa_max
            nRejectKappa = nRejectKappa + 1;
            continue;
        end

        if met.OCAER_dB > OCAER_max_dB
            nRejectOCAER = nRejectOCAER + 1;
            continue;
        end

        if useRippleConstraint && met.RipplePA_dB > Ripple_max_dB
            nRejectRipple = nRejectRipple + 1;
            continue;
        end

        SE_vals(n) = met.SE_gross;
        OCAER_vals(n) = met.OCAER_dB;
        Ripple_vals(n) = met.RipplePA_dB;
        Arel_vals(n) = met.Arel;
        Brel_vals(n) = met.Brel;
        kappaSpec_vals(n) = met.kappa_spec;
        DynRange_vals(n) = met.DynRange_dB;
        BW_vals(n) = met.BW99;
        valid(n) = true;

        if mod(n,100)==0 || n==1
            fprintf('%4d/%4d valid=%d  SE=%.4f  OC=%.2f dB  FoldPA=%.2f dB  kSpec=%.2f\n', ...
                n,N_rand,nnz(valid),met.SE_gross,met.OCAER_dB, ...
                met.RipplePA_dB,met.kappa_spec);
        end

    catch ME
        nFail = nFail + 1;
        if nFail <= 5
            fprintf(2,'Candidate %d failed: %s\n',n,ME.message);
        end
    end
end

fprintf('\nValid candidates: %d/%d; numerical failures: %d\n', ...
    nnz(valid),N_rand,nFail);
fprintf('Rejected by kappa: %d | OC-AER: %d | ripple: %d\n', ...
    nRejectKappa,nRejectOCAER,nRejectRipple);

if ~any(valid)
    error(['No valid CES candidate found. First rerun with useRippleConstraint=false ', ...
           'and inspect the corrected folded-spectrum metric/thresholds.']);
end

% Hard consistency checks: no candidate marked valid may violate screening.
assert(all(kappaSpec_vals(valid) <= kappa_max*(1+1e-12)), ...
    'Internal error: a valid candidate violates kappa_max.');
assert(all(OCAER_vals(valid) <= OCAER_max_dB+1e-12), ...
    'Internal error: a valid candidate violates OC-AER constraint.');
if useRippleConstraint
    assert(all(Ripple_vals(valid) <= Ripple_max_dB+1e-12), ...
        'Internal error: a valid candidate violates ripple constraint.');
end

fprintf('Valid-set kappa range: %.6g to %.6g (limit %.6g)\n', ...
    min(kappaSpec_vals(valid)),max(kappaSpec_vals(valid)),kappa_max);

%% =================== 7) Pareto analysis ================================
idx = find(valid);
SEv = SE_vals(idx);
OAv = OCAER_vals(idx);
Rv = Ripple_vals(idx);

Nv = numel(idx);
dom = false(Nv,1);

% Objectives: maximize SE, minimize OC-AER, minimize folded PA ripple.
% Stability is imposed separately by kappa_inf = B_tau/A_tau <= kappa_max.
% OC-AER and ripple are also screened by their application-specific upper
% bounds before Pareto filtering.
for ii = 1:Nv
    for jj = 1:Nv
        if ii == jj, continue; end
        if (SEv(jj) >= SEv(ii)) && (OAv(jj) <= OAv(ii)) && (Rv(jj) <= Rv(ii)) && ...
           ((SEv(jj) > SEv(ii)) || (OAv(jj) < OAv(ii)) || (Rv(jj) < Rv(ii)))
            dom(ii) = true;
            break;
        end
    end
end

idxP = idx(~dom);
[~,ord] = sort(SE_vals(idxP),'descend');
idxP = idxP(ord);

fprintf('\nTop Pareto CES designs (sorted by SE):\n');
Nprint = min(10,numel(idxP));
for ii = 1:Nprint
    jj = idxP(ii);
    fprintf(['#%2d: SE=%.4f | BW99=%.4f MHz | OC=%.2f dB | FoldPA=%.2f dB | ', ...
             'kSpec=%.3f (%.2f dB) | Arel=%.3e | theta=['], ...
        ii,SE_vals(jj),BW_vals(jj)/1e6,OCAER_vals(jj),Ripple_vals(jj), ...
        kappaSpec_vals(jj),DynRange_vals(jj),Arel_vals(jj));
    fprintf(' %.6f',theta_all(jj,:));
    fprintf(' ]\n');
end

%% =================== 8) Final Pareto-point selection ==================
SEmaxPareto = max(SE_vals(idxP));
SEfloor = (1-SE_selection_tol)*SEmaxPareto;
idxNear = idxP(SE_vals(idxP) >= SEfloor);

if isempty(idxNear)
    error('Internal error: no Pareto point lies inside the SE selection window.');
end

% Select the best-conditioned candidate within the 0.5%-of-max-SE window.
[~,iiBest] = min(kappaSpec_vals(idxNear));
selectedIdx = idxNear(iiBest);
selectedTheta = theta_all(selectedIdx,:);
p_selected = designCesPulseFromPhi_generalN(selectedTheta,SPS,spanSide);
metSelected = evaluate_pulse_metrics(p_selected,fs,Rb_gross,Rb_net, ...
    rho_eff,L_ftn,nfft,mask);
selectedParetoRank = find(idxP==selectedIdx,1,'first');

% Backward-compatible aliases for any downstream validation code.
bestIdx = selectedIdx;
bestTheta = selectedTheta;
p_best = p_selected;
metBest = metSelected;

fprintf('\n================ SELECTED CES DESIGN ====================\n');
fprintf('Selection rule: Pareto SE >= %.3f%% of max Pareto SE, then min kappa_spec\n', ...
    100*(1-SE_selection_tol));
fprintf('Maximum Pareto SE       = %.6f\n',SEmaxPareto);
fprintf('SE selection floor      = %.6f\n',SEfloor);
fprintf('Candidates in SE window = %d\n',numel(idxNear));
fprintf('Selected Pareto rank     = %d (ranked by descending SE)\n',selectedParetoRank);
fprintf('theta = ['); fprintf(' %.6f',selectedTheta); fprintf(' ]\n');
fprintf('SE       = %.6f bit/s/Hz\n',metSelected.SE_gross);
fprintf('BW99     = %.6f MHz\n',metSelected.BW99/1e6);
fprintf('OC-AER   = %.3f dB   (limit %.3f dB)\n', ...
    metSelected.OCAER_dB,OCAER_max_dB);
fprintf('Ripple   = %.3f dB   (limit %.3f dB)\n', ...
    metSelected.RipplePA_dB,Ripple_max_dB);
fprintf('Arel     = %.6e\n',metSelected.Arel);
fprintf('Brel     = %.6e\n',metSelected.Brel);
fprintf('kappa    = %.6g (%.3f dB)   (limit %.6g)\n', ...
    metSelected.kappa_spec,metSelected.DynRange_dB,kappa_max);

kappaStored = kappaSpec_vals(selectedIdx);
kappaRelErr = abs(metSelected.kappa_spec-kappaStored)/max(abs(kappaStored),realmin);
fprintf('Stored/recomputed kappa relative difference = %.3e\n',kappaRelErr);
assert(kappaRelErr < 1e-10, ...
    'Selected candidate metric changed between search and validation.');

% Final hard-constraint verification.
assert(isfinite(metSelected.kappa_spec) && ...
       metSelected.kappa_spec <= kappa_max*(1+1e-10), ...
    'Selected CES pulse violates kappa_max.');
assert(metSelected.OCAER_dB <= OCAER_max_dB+1e-10, ...
    'Selected CES pulse violates OC-AER constraint.');
if useRippleConstraint
    assert(metSelected.RipplePA_dB <= Ripple_max_dB+1e-10, ...
        'Selected CES pulse violates ripple constraint.');
end
fprintf('All hard constraints verified.\n');
fprintf('==========================================================\n');

fprintf('\nPareto-set kappa range: %.6g to %.6g\n', ...
    min(kappaSpec_vals(idxP)),max(kappaSpec_vals(idxP)));
fprintf('Near-max-SE kappa range: %.6g to %.6g\n', ...
    min(kappaSpec_vals(idxNear)),max(kappaSpec_vals(idxNear)));

%% =================== 9) Finite-Gram convergence diagnostic ============
% Diagnostic only.  The screening/selection constraint above uses the
% direct folded-spectrum ratio kappa_spec, not any finite-K matrix.
Klist = [5 16 32 64 128];

fprintf('\nFinite Toeplitz Gram diagnostic for SELECTED candidate:\n');
fprintf('theta ='); fprintf(' %.6f',selectedTheta); fprintf('\n');
for Kmat = Klist
    [A_K,B_K,kappa_K] = finite_gram_bounds(p_selected,L_ftn,Kmat);
    fprintf('  K=%3d: A_K=%.6e, B_K=%.6e, kappa_K=%.6g\n', ...
        Kmat,A_K,B_K,kappa_K);
end
fprintf('  Direct folded-spectrum kappa_spec = %.6g\n',metSelected.kappa_spec);

%% =================== 10) Optional plots ================================
figure;
plot(metSRRC.fold_f/1e6,10*log10(metSRRC.fold_norm+1e-14),'LineWidth',1.5); hold on;
plot(metSelected.fold_f/1e6,10*log10(metSelected.fold_norm+1e-14),'LineWidth',1.5);
grid on;
xlabel('Folded-spectrum frequency (MHz)');
ylabel('Normalized folded spectrum (dB)');
legend('SRRC','CES selected','Location','best');
title(sprintf('Correct FTN folded spectrum, \\tau=%.2f',rho_eff));

figure;
scatter(OCAER_vals(valid),SE_vals(valid),18,Ripple_vals(valid),'filled'); hold on;
scatter(OCAER_vals(idxP),SE_vals(idxP),36,'k');
scatter(OCAER_vals(selectedIdx),SE_vals(selectedIdx),70,'d','LineWidth',1.5);
grid on;
xlabel('OC-AER (dB)');
ylabel('Gross SE (bit/s/Hz)');
cb=colorbar; ylabel(cb,'Folded peak/average ripple (dB)');
legend({'Valid','Pareto','Selected'},'Location','best');
title(sprintf('Empirical CES Pareto set, \\tau=%.2f',rho_eff));

%% ======================================================================
%% SUPPORT FUNCTIONS
%% ======================================================================
function alpha = theta2alpha(theta)
% theta = [sigma1 omega1 sigma2 omega2 ...]
% Generates OPPOSITE-SIGN pole pairs {alpha,-alpha}:
%   alpha_i = sigma_i + j*omega_i
% This is NOT, in general, a complex-conjugate pairing.
P = numel(theta)/2;
alpha = zeros(1,2*P);
for ii = 1:P
    sigma = theta(2*ii-1);
    omega = theta(2*ii);
    a = sigma + 1j*omega;
    alpha(2*ii-1) = a;
    alpha(2*ii) = -a;
end
end

function met = evaluate_pulse_metrics(p,fs,Rb_gross,Rb_net,rho,L_ftn,nfft,mask)
p = p(:);
p = p/sqrt(sum(abs(p).^2));

% Pulse spectrum. For white iid symbols the transmit PSD is proportional to |P(f)|^2.
[H,w] = freqz(p,1,nfft,'whole');
H = fftshift(H);
w = w-pi;
f = w*(fs/(2*pi));
Pow = abs(H).^2;
df = f(2)-f(1);
Pow = Pow/(sum(Pow)*df + eps);

% FULL 99%-occupied bandwidth (not half-bandwidth).
BW99 = two_sided_bw_cdf(f,Pow,mask);
SE_gross = (Rb_gross/rho)/BW99;
SE_net = (Rb_net/rho)/BW99;

% FTN Nyquist cell: half-width = packed symbol rate / 2.
f_alias = fs/L_ftn;
fcell = f_alias/2;
Ein = sum(Pow(abs(f)<=fcell))*df;
Eout = sum(Pow(abs(f)>fcell))*df;
OCAER_dB = 10*log10((Eout+eps)/(Ein+eps));

% Evaluate over one fundamental cell [-f_alias/2, f_alias/2].
Nfold = max(2048,2^nextpow2(4*nfft/L_ftn));
fold_f = linspace(-f_alias/2,f_alias/2,Nfold).';
Sfold = zeros(size(fold_f));

for r = 0:L_ftn-1
    fshift = fold_f + r*f_alias;
    fwrap = wrapToInterval(fshift,-fs/2,fs/2);
    Sfold = Sfold + interp1(f,Pow,fwrap,'linear',0);
end
Sfold = Sfold/L_ftn;  % scaling does not affect ripple/condition ratios

Smean = mean(Sfold);
Smin = min(Sfold);
Smax = max(Sfold);
Arel = Smin/(Smean+eps);
Brel = Smax/(Smean+eps);
if Smin <= 0
    kappa_spec = inf;
else
    kappa_spec = Smax/Smin;
end
DynRange_dB = 10*log10(kappa_spec);
RipplePA_dB = 10*log10(Smax/(Smean+eps));

met = struct;
met.BW99 = BW99;
met.SE_gross = SE_gross;
met.SE_net = SE_net;
met.OCAER_dB = OCAER_dB;
met.RipplePA_dB = RipplePA_dB;
met.Smin = Smin;
met.Smax = Smax;
met.Arel = Arel;
met.Brel = Brel;
met.kappa_spec = kappa_spec;
met.DynRange_dB = DynRange_dB;
met.fold_f = fold_f;
met.fold_norm = Sfold/(Smean+eps);
met.f = f;
met.Pow = Pow;
end

function [A,B,kappa] = finite_gram_bounds(p,L,Kmat)
% Kmat is the actual matrix dimension.
p = p(:);
maxLag = Kmat-1;
gpos = zeros(Kmat,1);
for ell = 0:maxLag
    s = ell*L;
    if s >= numel(p)
        gpos(ell+1) = 0;
    else
        gpos(ell+1) = sum(p(1+s:end).*conj(p(1:end-s)));
    end
end
G = toeplitz(gpos,conj(gpos));
G = (G+G')/2;
e = real(eig(G));
A = min(e);
B = max(e);
if A <= 0
    kappa = inf;
else
    kappa = B/A;
end
end

function BW = two_sided_bw_cdf(f,PSD,mask)
df = f(2)-f(1);
PSD = PSD/(sum(PSD)*df + eps);
cdfv = cumsum(PSD)*df;
low = (1-mask)/2;
high = 1-low;
iL = find(cdfv>=low,1,'first');
iU = find(cdfv>=high,1,'first');
if isempty(iL) || isempty(iU)
    BW = NaN;
else
    BW = abs(f(iU)-f(iL));
end
end

function p = designCesPulseFromPhi_generalN(theta,SPS,span)
Nfft_design = 8192;
Om = pi*SPS;
Kalias = 20;  % larger truncation for the cardinal alias sum
alpha = theta2alpha(theta);
[phi,~] = build_cardinal_phi_N(alpha,span,Om,Nfft_design,Kalias);
p = phi(:);
if any(~isfinite(p)) || norm(p)==0
    error('Invalid CES pulse produced.');
end
p = p/sqrt(sum(abs(p).^2));
end

function [phi,t] = build_cardinal_phi_N(lambda,span,Om,Nfft,K)
n = (0:Nfft-1).';
dw = 2*Om/Nfft;
w = -Om+n*dw;

beta = compute_beta_hat_N(w,lambda);
A = zeros(size(w));
for kk = -K:K
    A = A + compute_beta_hat_N(w+2*pi*kk,lambda);
end

% Reject near-singular cardinal denominator rather than silently forcing it.
scaleA = max(abs(A));
if ~isfinite(scaleA) || scaleA==0
    error('Cardinal denominator is numerically invalid.');
end
if min(abs(A)) < 1e-10*scaleA
    error('Cardinal denominator nearly singular for this pole set.');
end

phi_hat = beta./A;
phi = fftshift(ifft(ifftshift(phi_hat)))*(dw/(2*pi));

% dt = 1/SPS because Om=pi*SPS.
dt = 2*pi/(Nfft*dw);
m = (-Nfft/2:Nfft/2-1).';
t = m*dt;

idx = abs(t)<=span;
phi = phi(idx);
t = t(idx);

[~,i0] = min(abs(t));
if abs(phi(i0)) < 1e-12
    error('CES cardinal sample at t=0 is too small.');
end
phi = phi/phi(i0);
end

function b = compute_beta_hat_N(w,lambda)
b = ones(size(w));
for ll = 1:numel(lambda)
    lam = lambda(ll);
    z = 1i*w-lam;
    % Handle removable singularity near z=0 using the analytic limit 1.
    term = (1-exp(-z))./z;
    near0 = abs(z)<1e-10;
    if any(near0)
        % 1-exp(-z) = z-z^2/2+..., hence term = 1-z/2+...
        term(near0) = 1-z(near0)/2+z(near0).^2/6;
    end
    b = b.*term;
end
end

function y = wrapToInterval(x,minVal,maxVal)
L = maxVal-minVal;
y = x-L.*floor((x-minVal)./L);
% Keep exact upper-edge values numerically inside interpolation interval.
y(y>=maxVal) = minVal;
end
